# END-USER LICENSE AGREEMENT (EULA)
## MOPROTEC COPYRIGHTER

**© 2026 Morley Moses Apooch. All rights reserved.**

---

## IMPORTANT: READ BEFORE INSTALLATION

By downloading, installing, or using MOPROTEC Copyrighter ("Software"), you agree to be bound by this End-User License Agreement ("EULA"). If you do not agree to these terms, you must NOT install or use the Software.

---

## 1. PARTIES & EFFECTIVE DATE

**Licensor (Publisher & Owner):** Morley Moses Apooch  
**Creator Organization:** CLEAN HANDS CLEAN MONEY FAM  
**Software Name:** MOPROTEC Copyrighter  
**Software Type:** Flutter Mobile Application (iOS/Android)  
**License Effective Date:** August 22, 2026  
**Licensor Contact:** apoochmorley@protonmail.com  
**Status:** Status Indian, Band Member #3760080802, Yellow Quill First Nations

**Licensee:** End-user (individual or organization) downloading from Google Play Store or authorized distributor

---

## 2. BERNE CONVENTION & INTERNATIONAL COPYRIGHT PROTECTION

### Automatic International Protection:

This Software is protected under:
- **Berne Convention for the Protection of Literary and Artistic Works** (1886, as amended)
- **Canadian Copyright Act** (R.S.C., 1985, c. C-42)
- **WIPO Copyright Treaty** (1996)
- **WCT Performances & Phonograms Treaty** (where applicable to proof-of-creation records)

**What This Means:**
Copyright protection is automatic in 174+ countries. No registration or notice is required. All intellectual property rights are reserved.

---

## 3. INDIGENOUS IDENTITY & RIGHTS ASSERTION

This Software is created by **Morley Moses Apooch**, a **status Indian and band member** under the Indian Act (R.S.C., 1985, c. I-5).

### Indigenous Protections:

The Software represents Indigenous innovation and technological sovereignty. This work is protected not only by copyright law but also by the legal rights available to Indigenous peoples under:

- **United Nations Declaration on the Rights of Indigenous Peoples (UNDRIP)**
  - Article 26: Right to lands, territories, and resources
  - Article 31: Right to maintain and protect intellectual property
  - Article 32: Right to determine development affecting Indigenous lands and resources

- **Indian Act Protections** — Status Indian privileges and protections
- **Aboriginal Rights & Title** — Under Canadian constitutional law
- **Treaty Rights** — Under applicable historical treaties
- **Yellow Quill First Nations Sovereignty** — Inherent rights of the nation

This EULA represents both proprietary licensing and Indigenous intellectual property assertion.

---

## 4. WHAT IS MOPROTEC COPYRIGHTER?

### Core Functionality:

MOPROTEC Copyrighter is a mobile application that provides:

**1. Proof-of-Creation Technology:**
- Photo/work capture with cryptographic proof
- SHA-256 hash generation (immutable fingerprint)
- Timestamp recording (exact creation date/time)
- QR code generation (scannable proof)
- PDF certificate export (printable evidence)

**2. Metadata Tagging:**
- GPS location recording
- Device identification
- Creator identification
- Witness/signature fields

**3. Cloud Backup:**
- Firebase cloud storage (secure, encrypted)
- Anonymous authentication (privacy-protected)
- 5GB free tier + premium storage options
- Automatic sync across devices

**4. Blockchain Anchoring:**
- Bitcoin (Mainnet & Testnet) proof-of-creation
- Ethereum Sepolia blockchain timestamp
- Chainpoint v3 anchoring
- OriginStamp fallback service
- Immutable proof of creation date

**5. Certificate Generation:**
- PDF certificate with legal assertions
- Berne Convention notice
- Blockchain proof-of-existence
- Timestamped signature lines

### Legal Purpose:

This Software is designed to provide cryptographic and blockchain-anchored proof of creation for:
- Copyright claims (literary and artistic works)
- Patent applications (novelty evidence)
- Trademark registration (proof of first use)
- Legal proceedings (evidence authentication)
- Academic/research attribution
- Business intellectual property

---

## 5. SUBSCRIPTION LICENSE GRANT

Subject to payment and compliance with this EULA, Morley Moses Apooch grants you a **limited, non-exclusive, non-transferable, terminable subscription license** to use the Software on your personal mobile device.

### License Scope:

**What You CAN Do:**
- Install Software on your personal device
- Use proof-of-creation features for personal use
- Generate certificates for personal works
- Access cloud backup for your creations
- Receive blockchain proof-of-creation anchoring
- Export certificates in PDF format
- Share certificates with third parties (proof of creation)

**What You CANNOT Do:**
- Reverse engineer or decompile the application
- Modify, adapt, or create derivative works
- Share your subscription license with others
- Transfer license to another person or device
- Use for commercial reproduction or distribution
- Build competing proof-of-creation services
- Extract source code or proprietary algorithms
- Remove copyright notices or proprietary labels
- Disable obfuscation, encryption, or license verification
- Bypass subscription verification or tamper with license keys

---

## 6. SUBSCRIPTION TERMS & PAYMENT

### License Fee Structure:

| Item | Details |
|------|---------|
| **Trial Period** | 14 days (free, full-featured) |
| **Subscription Term** | Annual ($29.99 CAD) |
| **Renewal** | Automatic annual renewal unless cancelled |
| **Currency** | Canadian Dollars (CAD) |
| **Payment Method** | Interac e-Transfer (automated) |
| **Billing Contact** | apoochmorley@protonmail.com |
| **Tax** | Applicable sales tax (if required) |

### Payment Process:

1. **Trial Activation:** Download + 14-day free trial begins automatically
2. **Payment Request:** On Day 14, Interac e-Transfer payment request issued
3. **License Activation:** Upon receipt of payment, license key issued via email
4. **Annual Renewal:** Same process occurs on anniversary date

### Billing & Cancellation:

- **Billing Date:** Annual on subscription anniversary
- **Cancellation:** Email apoochmorley@protonmail.com (at least 7 days before renewal)
- **Refund Policy:** No refunds after Day 7 (7-day trial refund window only)
- **Non-Payment:** License terminates if payment not received within 30 days of renewal notice

---

## 7. LICENSE KEY & ACTIVATION

### License Key System:

Each subscription includes a unique **License Key** that:
- Activates features after 14-day trial expires
- Is bound to your email address and device
- Cannot be shared or transferred
- Expires on anniversary date (requires renewal payment)
- Is disabled if subscription is cancelled

### Activation Requirements:

- License key required after trial period
- License key emailed within 24 hours of payment confirmation
- Key enters via email or in-app settings
- Device must have internet connection for verification
- Activation fails if license key is invalid or expired

### Key Management:

- **One Key Per Subscription** — Each subscription grants one active key
- **No Key Sharing** — Sharing your key with others violates this EULA
- **Key Replacement** — If lost, request new key via apoochmorley@protonmail.com (fee applies if due to negligence)

---

## 8. BLOCKCHAIN PROOF-OF-CREATION TECHNOLOGY

### What It Does:

When you create a proof-of-creation certificate in MOPROTEC, the Software:

1. **Calculates SHA-256 Hash** — Cryptographic fingerprint of your work
2. **Records Timestamp** — Exact creation date/time (to the second)
3. **Submits to Blockchain** — Anchors hash to blockchain network
4. **Receives Confirmation** — Blockchain transaction ID provided
5. **Generates Certificate** — PDF with blockchain proof embedded

### Blockchain Networks Used:

- **Bitcoin Mainnet** — Primary blockchain anchor (most immutable)
- **Bitcoin Testnet** — Secondary testing network
- **Ethereum Sepolia** — Ethereum blockchain anchor
- **Chainpoint v3** — Standardized anchor format
- **OriginStamp** — Fallback timestamping service

### What Blockchain Proof Establishes:

- **Immutable Timestamp** — Proof you created work on specific date/time
- **Cryptographic Integrity** — Work has not been modified since creation
- **Public Record** — Blockchain is public, permanent, censorship-resistant
- **Admissible Evidence** — Legal systems recognize blockchain timestamps

### Legal Significance:

Blockchain proof-of-creation is admissible evidence in:
- **Copyright Registration** — Supporting novelty/originality claims
- **Patent Applications** — Proving first-to-invent dates
- **Trademark Applications** — Demonstrating prior use evidence
- **Litigation** — Supporting ownership claims in court
- **Commercial Disputes** — Establishing creation date for royalties
- **Insurance Claims** — Valuation and loss documentation

### Cost & Fees:

- Blockchain anchoring included in subscription ($29.99 CAD/year)
- No additional per-certificate fee
- Unlimited blockchain proofs per year
- Blockchain transaction fees (paid by Software, not user)

---

## 9. FIREBASE CLOUD BACKUP & PRIVACY

### Cloud Storage Features:

- **Secure Encryption** — All data encrypted at rest and in transit
- **Anonymous Authentication** — You don't need to create an account
- **Privacy First** — Minimal personal data collection
- **5GB Free Tier** — Included with subscription
- **Premium Storage** — Additional storage available (separate fee)

### Data You Control:

- Your certificates and proofs
- Your work metadata (date, location, creator info)
- Your blockchain anchoring records
- Automatic sync across your devices

### Data MOPROTEC Does NOT Store:

- Payment information (handled by payment processor)
- Your personal identification beyond email
- Commercial data about your works
- Third-party usage or redistribution info

### Privacy Terms:

- MOPROTEC is designed for privacy (anonymous auth)
- Morley Moses Apooch does not share your data with third parties
- Firebase (Google) terms apply to cloud storage (see https://firebase.google.com/terms)
- You control what you back up and can delete anytime
- All data encrypted; no unencrypted backup to servers

---

## 10. CERTIFICATE & PROOF-OF-CREATION TERMS

### What a Certificate Includes:

Each PDF certificate generated includes:

```
CERTIFICATE OF CREATION
Work Title: [Your Title]
Creator: [Your Name]
Creation Date: [ISO 8601 Timestamp]
SHA-256 Hash: [Cryptographic Hash]
Blockchain Anchor: [Transaction ID]
Copyright Notice: © [Year] [Your Name]. All rights reserved.
Berne Convention Notice: Protected under international copyright treaty
Status Indian Work: [If applicable]
QR Code: [Scannable blockchain proof]
```

### Legal Assertions in Certificate:

Each certificate includes Berne Convention language asserting:
- Your copyright in the work
- Creation date and authenticity
- Immutable blockchain proof
- Right to exclude others from use
- International protection (174+ countries)

### Certificate Validity:

- Certificates are permanent (blockchain is immutable)
- Blockchain proof never expires
- Historical certificates available in app archive
- Export/print certificates anytime
- Certificates remain valid after subscription expires

### Your Rights via Certificate:

By holding a certificate, you establish:
- **Copyright ownership** — Under Berne Convention
- **Creation date** — Legal proof of when work was created
- **Authenticity** — Proof work has not been modified
- **Exclusive rights** — Right to control reproduction, distribution, derivative works
- **Damages claim** — Statutory damages available for infringement

---

## 11. INTELLECTUAL PROPERTY OWNERSHIP

### What You Own:

- Your original work (photo, document, etc.)
- Your certificates and blockchain proofs
- Your email and metadata associated with your account
- Export rights to your certificates (PDF download)

### What You DON'T Own:

- The Software itself (proprietary to Morley Moses Apooch)
- The proof-of-creation technology (proprietary)
- The blockchain anchoring service (proprietary)
- Improvements or derivative works
- The "MOPROTEC" brand and trademarks
- The certificate templates and designs

### Creator's Retained Rights:

Morley Moses Apooch retains:
- All intellectual property in the Software
- Right to update, modify, or discontinue the service
- Right to use anonymous, aggregated analytics
- Right to improve proof-of-creation technology
- Ownership of all trademark and branding

---

## 12. RESTRICTIONS & PROHIBITED USE

You agree NOT to:

### Technical Restrictions:
- Decompile, disassemble, or reverse engineer the Software
- Extract source code or proprietary algorithms
- Defeat license verification or obfuscation
- Modify binary files or bypass security measures
- Create unauthorized updates or patches

### Distribution Restrictions:
- Share your subscription or license key
- Transfer license to another person
- Share the app via unauthorized channels
- Republish or redistribute the Software
- Modify and redistribute under different license

### Use Restrictions:
- Use for commercial reproduction service
- Build competing proof-of-creation services
- Use to infringe others' intellectual property rights
- Use to impersonate others or falsify proofs
- Create false or backdated certificates
- Bypass payment or use without license key

### Ethical Restrictions:
- Use to create fraudulent proofs of authorship
- Use to falsify creation dates for legal fraud
- Use in scams, phishing, or social engineering
- Use to circumvent others' copyright protection
- Misuse blockchain anchoring for deception

---

## 13. WARRANTY DISCLAIMER & LIABILITY LIMITATIONS

### SOFTWARE PROVIDED "AS-IS":

**THIS SOFTWARE IS PROVIDED "AS-IS" WITHOUT WARRANTY OF ANY KIND.**

Morley Moses Apooch makes NO representations or warranties:

1. **NO WARRANTY OF MERCHANTABILITY** — Not guaranteed to be commercially viable
2. **NO WARRANTY OF FITNESS** — Not guaranteed for any particular purpose
3. **NO WARRANTY OF PERFORMANCE** — No guarantees of speed, accuracy, or reliability
4. **NO WARRANTY OF SECURITY** — No guarantee against hacking or data breach
5. **NO WARRANTY OF BLOCKCHAIN** — No guarantee blockchain networks will function
6. **NO WARRANTY OF SERVICE** — No guarantee of 24/7 uptime or availability
7. **NO WARRANTY OF ACCURACY** — No guarantee certificates are legally valid

### User Assumes All Risk:

By using this Software, you assume all risk of:
- Data loss or corruption
- Incorrect proof-of-creation
- Blockchain network failure
- Device damage or malfunction
- Security breach or unauthorized access
- Legal invalidity of certificates
- Blockchain anchor loss or corruption
- False or invalid proofs

---

### LIMITATION OF LIABILITY:

**IN NO EVENT SHALL MORLEY MOSES APOOCH BE LIABLE FOR:**

1. Direct, indirect, or consequential damages
2. Lost profits, revenue, or business
3. Lost data or work
4. System damage or failure
5. Third-party claims or litigation
6. Breach of certificate authenticity
7. Blockchain network failures
8. Firebase or cloud backup failures

**Even if advised of possibility of damages, this limitation applies.**

---

## 14. TERMINATION & CANCELLATION

### Subscription Termination:

Your subscription terminates if:
1. You fail to pay renewal fee within 30 days
2. Morley Moses Apooch terminates service (30 days notice)
3. You violate this EULA (immediate termination)
4. Software is discontinued by Morley Moses Apooch

### Upon Termination:

- License key is deactivated (cannot create new certificates)
- Cloud backup access is suspended (data not deleted)
- Blockchain anchoring service is unavailable
- Existing certificates remain valid (blockchain immutable)
- You may export remaining data within 30 days

### Survival After Termination:

- Existing certificates are permanent (blockchain is immutable)
- Blockchain proofs remain valid
- Historical data remains retrievable (within grace period)
- Copyright in your works remains yours

---

## 15. CANADIAN COPYRIGHT ACT ENFORCEMENT

### Available Remedies:

If you breach this EULA, Morley Moses Apooch may pursue remedies under the Canadian Copyright Act:

**Civil Remedies:**
- **Injunctions** — Court order to cease infringement
- **Statutory Damages** — $100-$5,000 per work (unintentional), $500-$20,000 (willful)
- **Actual Damages** — Proof of economic loss
- **Defendant's Profits** — Disgorgement of profits from infringement
- **Attorney's Fees** — Recovery of legal costs

**Criminal Remedies (Willful Infringement):**
- **Fine** — Up to $1,000,000
- **Imprisonment** — Up to 5 years
- **Asset Seizure** — Confiscation of infringing materials

---

## 16. BLOCKCHAIN PROOF-OF-CREATION EVIDENCE

### Admissibility in Legal Proceedings:

Certificates generated by MOPROTEC include:
- **SHA-256 Hash** — Cryptographic proof of work authenticity
- **Timestamp** — Immutable creation date (blockchain-verified)
- **Blockchain Anchor** — Public transaction ID (independently verifiable)
- **Digital Signature** — Creator identity verification
- **Berne Convention Notice** — International copyright assertion

This evidence is admissible in:
- Canadian courts (evidence rules recognize blockchain proof)
- U.S. courts (blockchain evidence increasingly accepted)
- International arbitration
- Patent & trademark offices
- Copyright registration authorities

### Using Certificates as Evidence:

If you use MOPROTEC certificates in legal proceedings:
1. You assert the creation date is accurate
2. You attest you are the original creator
3. You warrant you have not tampered with certificate
4. You may be cross-examined on certificate accuracy
5. False statements in certificate may constitute perjury

**Use certificates honestly and accurately.**

---

## 17. CONTACT & CUSTOMER SUPPORT

### Support Contact:
**Email:** apoochmorley@protonmail.com  
**Subject:** "MOPROTEC Support - [Your Issue]"

### Response Times:
- **Technical Issues:** 2-7 business days
- **Payment Problems:** 24-48 hours
- **Account Issues:** 2-5 business days
- **License Key:** 24 hours

### What Support Covers:
- Installation assistance
- License key activation
- Account management
- Payment inquiries
- Certificate export help

### What Support Does NOT Cover:
- Legal advice on certificate validity
- Guarantee of blockchain success
- Cloud backup recovery (user responsibility)
- Device or OS technical issues

---

## 18. PRIVACY & DATA PROTECTION

### Personal Data Collected:

Minimal data collection:
- Email address (for license key delivery)
- Device ID (for license verification)
- Creation timestamps (your works)
- Blockchain transaction IDs (for proof verification)

### Data Not Collected:

- Payment card information (handled by payment processor)
- Biometric data
- Location data (beyond what you manually tag)
- Browsing history
- Usage analytics (minimal)

### Data Retention:

- **Active Subscriptions** — Data retained during subscription
- **Cancelled Subscriptions** — Data retained 30 days post-cancellation, then deleted
- **Cloud Backups** — You control deletion
- **Blockchain Records** — Permanent (blockchain immutable)

### Third-Party Services:

- **Firebase** — Google privacy policy applies (https://firebase.google.com/terms)
- **Payment Processor** — Interac e-Transfer (not controlled by MOPROTEC)
- **Blockchain Networks** — Bitcoin, Ethereum (public, immutable)
- **OriginStamp** — Fallback timestamping service

---

## 19. AMENDMENTS & MODIFICATIONS

### Modification Rights:

Morley Moses Apooch may modify this EULA:
- With 30 days notice (email to registered address)
- Changes effective on stated effective date
- Continued use = acceptance of new terms
- Objections: Cancel subscription within 30-day notice period

### Current Version:

- **Version:** 1.0
- **Effective Date:** August 22, 2026
- **Last Updated:** August 22, 2026

---

## 20. ENTIRE AGREEMENT

This EULA, combined with supplementary documents below, represents the entire agreement:

**Binding Documents:**
- This EULA
- Privacy Policy (in-app)
- Certificate Terms & Blockchain Disclaimer
- Firebase Terms of Service (for cloud backup)
- Interac e-Transfer Terms (for payment)

**No Other Terms Apply:**
- No verbal promises or modifications
- No implied warranties or conditions
- No third-party beneficiaries
- No waiver of terms by non-enforcement

---

## 21. GOVERNING LAW & JURISDICTION

### Jurisdiction:
- **Primary:** Saskatchewan, Canada
- **Secondary:** Federal Court of Canada

### Governing Law:
- **Canadian Copyright Act** (R.S.C., 1985, c. C-42)
- **Berne Convention** (international copyright treaty)
- **WIPO Copyright Treaty** (1996)
- **Saskatchewan Law** (contracts and remedies)

### Dispute Resolution:
- Disputes must be litigated in Canadian courts
- No arbitration clause
- Pro se litigation permitted
- Morley Moses Apooch represents himself (pro se)

---

## 22. SPECIAL PROVISIONS

### Pro Se Representation:

"Morley Moses Apooch represents himself in legal matters and negotiations. All legal communications should be directed to: apoochmorley@protonmail.com"

### Indigenous Identity Notice:

This Software is created by Morley Moses Apooch, a status Indian and band member. The Software represents Indigenous innovation and technological sovereignty, protected not only by copyright but also by Indigenous legal rights under UNDRIP.

### Status Indian Both Email Addresses:

Both email addresses (apoochmorley@protonmail.com and moapooch121@gmail.com) represent the same creator and legal owner. They are used interchangeably for all business purposes.

---

## 23. FINAL LEGAL NOTICE

**© 2026 Morley Moses Apooch. All rights reserved.**

MOPROTEC Copyrighter is proprietary software and proof-of-creation technology. Unauthorized use, reproduction, redistribution, or modification is strictly prohibited.

**By installing or using this Software, you acknowledge that:**
1. You have read and understood this entire EULA
2. You agree to all terms and conditions
3. You understand subscription terms and payment obligations
4. You accept "as-is" disclaimers and liability limitations
5. You warrant you will use certificates honestly
6. You understand blockchain proof-of-creation limitations

---

## 24. VERSION INFORMATION

| Item | Value |
|------|-------|
| **Software Version** | Current (v1.0+) |
| **EULA Version** | 1.0 |
| **Effective Date** | August 22, 2026 |
| **Creator** | Morley Moses Apooch |
| **Creator Status** | Status Indian, Band #3760080802 |
| **Jurisdiction** | Canada (Saskatchewan/Federal) |
| **Governing Law** | Canadian Copyright Act + Berne Convention |

---

**ACCEPTANCE CONFIRMATION:**

By clicking "I Accept" or installing the Software, you confirm:
- [ ] I have read this entire EULA
- [ ] I understand all terms and conditions
- [ ] I agree to be bound by this EULA
- [ ] I understand subscription payment terms
- [ ] I accept liability limitations and disclaimers

**Installation Date:** ________________  
**License Activation:** ________________  
**Annual Renewal Date:** ________________

---

*This EULA represents proprietary licensing of Indigenous technological innovation. All intellectual property rights are owned by Morley Moses Apooch, a status Indian and band member of Yellow Quill First Nations. This Software is protected by international copyright law (Berne Convention) and Canadian law.*

**For all inquiries: apoochmorley@protonmail.com**
