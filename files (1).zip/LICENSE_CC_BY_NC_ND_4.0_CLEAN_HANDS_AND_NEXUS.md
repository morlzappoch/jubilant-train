# Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International

## CLEAN HANDS CLEAN MONEY FAM & NEXUS SOVEREIGN SEARCH

**© 2026 Morley Moses Apooch. All rights reserved.**

---

## 1. BERNE CONVENTION PROTECTION

This work is protected under the **Berne Convention for the Protection of Literary and Artistic Works** (1886, as amended). As a work created by a Canadian resident, automatic copyright protection extends to all signatory countries of the Berne Convention (currently 174+ countries).

**Explicit Notice:**
This work does NOT require registration to receive copyright protection. All rights are automatically reserved and protected by international treaty.

---

## 2. CANADIAN COPYRIGHT PROTECTION

This work is protected under the **Canadian Copyright Act** (R.S.C., 1985, c. C-42), which provides comprehensive protection including:
- Automatic copyright upon creation (no registration required)
- Statutory damages for infringement
- Criminal penalties for willful copyright infringement
- International treaty obligations (WIPO, Berne Convention, WCT)

---

## 3. INDIGENOUS IDENTITY & PROTECTIONS

This work is created by **Morley Moses Apooch**, a **status Indian and band member** (Band #3760080802, Yellow Quill First Nations).

**Indigenous Protections Clause:**

The creator asserts copyright and intellectual property rights under international law AND the legal protections available to Indigenous peoples. This work represents Indigenous innovation and technological sovereignty. The assertion of copyright herein does not waive or diminish:

- Aboriginal rights and title under Canadian law
- Inherent sovereignty of Yellow Quill First Nations
- Rights protected under the **United Nations Declaration on the Rights of Indigenous Peoples (UNDRIP)**, particularly:
  - Article 26: Right to lands, territories, and resources
  - Article 31: Right to maintain and protect intellectual property
  - Article 32: Right to determine development affecting Indigenous lands and resources
- Treaty rights under applicable historical treaties

**This work is an assertion of Indigenous intellectual property rights.**

---

## 4. LICENSE TERMS

### Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International

This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License. To view a copy of this license, visit:
https://creativecommons.org/licenses/by-nc-nd/4.0/

### You are free to:

**Share** — Copy and redistribute the material in any medium or format, provided you:
- Comply with all terms of this license
- Include the copyright attribution
- Acknowledge Indigenous creation
- Do not modify or adapt the work

### Under the following conditions:

**Attribution** — You must give appropriate credit to Morley Moses Apooch, provide a link to this license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

**NonCommercial** — You may not use the material for commercial purposes. "Commercial purposes" includes:
- Selling the material or derivative works
- Using it as a service for paying customers
- Incorporating it into a for-profit product or service
- Monetizing access via subscription, licensing, or usage fees (except as explicitly permitted below)
- Using it for commercial advertising, marketing, or promotional purposes
- Including it in corporate or business training materials for sale

**Exception — Author Commercial Use:**
The creator (Morley Moses Apooch) and CLEAN HANDS CLEAN MONEY FAM retain the right to use this work for commercial purposes, including:
- Website sponsorships and advertising (CLEAN HANDS CLEAN MONEY FAM website)
- Bitcoin subscriptions (Nexus Sovereign Search)
- Commercial partnerships and services
- Corporate licensing arrangements

This exception applies ONLY to works created by Morley Moses Apooch and does NOT extend to third parties.

**NoDerivatives** — If you remix, transform, or build upon the material, you may NOT distribute the modified material. You may not create derivative works for any purpose—educational, personal, or otherwise—without explicit written permission from Morley Moses Apooch.

### No additional restrictions:

You may not apply legal terms or technological measures that legally restrict others from doing anything this license permits.

---

## 5. CREATOR IDENTITY & CONTACT

| Designation | Value |
|---|---|
| Creator Name | Morley Moses Apooch |
| Organization | CLEAN HANDS CLEAN MONEY FAM |
| Role | Founder, Lead Software Architect |
| Email (Primary) | apoochmorley@protonmail.com |
| Email (Secondary) | moapooch121@gmail.com |
| Indigenous Status | Status Indian, Band #3760080802 |
| Jurisdiction | Yellow Quill, Saskatchewan, Canada |

**Important Identity Note:**
Both email addresses (apoochmorley@protonmail.com and moapooch121@gmail.com) represent the same legal person and owner. They are used interchangeably for project administration, payment processing, licensing inquiries, and legal communications.

---

## 6. PROJECTS COVERED BY THIS LICENSE

### CLEAN HANDS CLEAN MONEY FAM
- Indigenous-led ethical financial infrastructure
- React prototype + Flutter production build
- Dashboard, accounts, loans, community, security, investors features
- Embedded Certificate Generator component
- License Status: CC BY-NC-ND 4.0 (with author exceptions for ads/sponsors)

### NEXUS SOVEREIGN SEARCH
- Local search engine and evidence indexing system
- Legal agreement + code indexing
- SHA-256 proof-of-creation + PDF certificates
- Bitcoin tiered subscriptions (Starter, Guardian, Fortress)
- License Status: CC BY-NC-ND 4.0 (with author exceptions for Bitcoin subscriptions)

---

## 7. WHAT THIS LICENSE DOES NOT PERMIT

Without explicit written permission from Morley Moses Apooch, you may NOT:

1. **Create derivative works** — Modify, adapt, remix, or translate the work
2. **Commercial distribution** — Sell, resell, or distribute for commercial gain
3. **Commercial services** — Offer the work as a paid service or subscription
4. **Incorporate into commercial products** — Use as a component in for-profit applications
5. **License to third parties** — Sublicense or grant rights to others
6. **Remove attribution** — Strip creator attribution or copyright notices
7. **Claim authorship** — Represent the work as your own creation
8. **Reverse engineer** — Decompile, disassemble, or extract proprietary components
9. **Remove Indigenous identity** — Erase or obscure the Indigenous creation status
10. **Use for commercial advertising** — Incorporate into paid marketing or advertising campaigns

---

## 8. BLOCKCHAIN PROOF-OF-CREATION

This work is anchored on blockchain networks for immutable proof-of-creation:

**Projects with Blockchain Anchoring:**
- CLEAN HANDS CLEAN MONEY FAM: Every major release version
- Nexus Sovereign Search: Per index update and release
- Certificate Generator: Per certificate generation

**Blockchain Networks Used:**
- Bitcoin Mainnet
- Bitcoin Testnet
- Ethereum Sepolia
- Chainpoint v3
- OriginStamp (fallback service)

**What Blockchain Anchoring Proves:**
- Exact creation date and time (immutable timestamp)
- Cryptographic integrity of the work (SHA-256 hash)
- Authentic creator identity (transaction signature)
- No subsequent modifications (hash immutability)

**Legal Significance:**
Blockchain proof-of-creation provides evidence of:
- Original authorship under Berne Convention
- Compliance with copyright law requirements
- Damages calculation in infringement cases (statutory damages apply)
- Clear ownership documentation for pro se litigation

---

## 9. STATUTORY RIGHTS & REMEDIES

### Canadian Copyright Act Remedies Available to Creator:

If you infringe this work, Morley Moses Apooch may seek:

1. **Civil Remedies:**
   - Injunctions against infringement
   - Actual damages (loss of revenue)
   - Statutory damages: $100-$5,000 per work (unintentional), $500-$20,000 (willful)
   - Defendant's profits from infringement
   - Extraordinary damages for flagrant infringement

2. **Criminal Remedies (Willful Infringement):**
   - Fine up to $1,000,000
   - Imprisonment up to 5 years
   - Seizure and destruction of infringing materials

3. **Administrative Remedies:**
   - DMCA takedown notices (where applicable)
   - Cease-and-desist letters
   - Platform content removal requests
   - Domain name suspension (cybersquatting)

4. **Evidence Preservation:**
   - Immutable blockchain records
   - Git commit history (creation timestamps)
   - Email documentation (ownership)
   - SHA-256 integrity proofs

---

## 10. ATTRIBUTION REQUIREMENTS

If you share this work (permitted only for non-commercial purposes and without modifications), you must:

### Minimum Attribution Format:

```
Based on [WORK NAME] by Morley Moses Apooch
CC BY-NC-ND 4.0 License
https://creativecommons.org/licenses/by-nc-nd/4.0/

Status Indian Work | Band Member #3760080802 | Yellow Quill First Nations
© 2026 Morley Moses Apooch. All rights reserved.
```

### Or in Text Form:

"This project uses [WORK NAME] by Morley Moses Apooch, licensed under CC BY-NC-ND 4.0. The original work is protected under Berne Convention and is created by a status Indian. For licensing inquiries, contact apoochmorley@protonmail.com."

### Visual Placement:

- Visible in documentation/README (not hidden in footer)
- Credited in research papers/academic works
- Mentioned in video descriptions and slide presentations
- Included in software credits/about pages

---

## 11. HOW TO REQUEST PERMISSIONS

### For Educational Use (with modifications):
Email: apoochmorley@protonmail.com
Include:
- Educational institution name
- Specific use case
- Proposed modifications
- Student/instructor information

### For Commercial Use (limited exception):
Email: apoochmorley@protonmail.com
Include:
- Business name and jurisdiction
- Commercial use case
- Revenue model
- Proposed licensing terms

### For Research/Academic Use:
Email: apoochmorley@protonmail.com
Include:
- Academic institution
- Research project overview
- Publication plan
- Attribution format

**Response Time:** 14-21 business days (permission inquiries)

---

## 12. DISCLAIMER

**THIS WORK IS PROVIDED "AS-IS" WITHOUT WARRANTIES OF ANY KIND.**

The creator makes no representations or warranties regarding:
- Fitness for a particular purpose
- Merchantability
- Non-infringement of third-party rights
- Functionality or performance
- Security or safety

Use at your own risk. The creator is not liable for:
- Data loss or corruption
- System damage or failure
- Business interruption
- Consequential or indirect damages
- Loss of profits or revenue

---

## 13. TERMINATION

This license is automatic and perpetual for lawful use. However, the license terminates immediately if you:

1. Violate any terms of this license
2. Use the work for commercial purposes (except as permitted)
3. Create derivative works
4. Breach attribution requirements
5. Attempt to remove Indigenous identity or copyright notices

Upon termination, you must cease all use and delete all copies.

---

## 14. DISPUTE RESOLUTION

### For Copyright Infringement Claims:

1. **Cease-and-Desist Notice** — 48 hours notification of alleged infringement
2. **Evidence Submission** — Creator provides proof via blockchain and documentation
3. **Negotiation Period** — 14 days to resolve informally
4. **Legal Action** — If unresolved, pro se litigation under Canadian law (Canadian Copyright Act)
5. **Jurisdiction** — Canadian courts (Saskatchewan preferred, Canada federal courts acceptable)

### For License Interpretation Disputes:

- Default interpretation: "author-friendly" (restrictions favoring creator)
- Ambiguous terms: Resolved in favor of Morley Moses Apooch
- Indigenous rights: Supersede commercial license terms
- Good faith required for all interpretations

---

## 15. CONTACT INFORMATION

| Purpose | Email | Response Time |
|---------|-------|----------------|
| License Inquiries | apoochmorley@protonmail.com | 14-21 days |
| Copyright Infringement | apoochmorley@protonmail.com | 24-48 hours |
| Permission Requests | apoochmorley@protonmail.com | 14-21 days |
| Commercial Licensing | apoochmorley@protonmail.com | 7-14 days |
| Technical Support | apoochmorley@protonmail.com | Variable |

---

## 16. SUPPLEMENTARY DOCUMENTS

This license is supplemented by:
- **COPYRIGHT.md** — Full copyright and ownership assertions
- **BERNE_CONVENTION.md** — Explicit Berne Convention notice
- **INDIGENOUS_PROTECTIONS.md** — Indigenous rights and protections
- **CONTRIBUTORS.md** — Attribution and contributor guidelines

All supplementary documents are binding and enforceable.

---

## 17. VERSION & EFFECTIVE DATE

| Item | Value |
|------|-------|
| License Version | 1.0 |
| Effective Date | August 22, 2026 |
| Jurisdiction | Canada (Saskatchewan/Federal) |
| Governing Law | Canadian Copyright Act (R.S.C., 1985, c. C-42) |
| International | Berne Convention + WIPO Copyright Treaty |

---

## 18. FINAL NOTICE

**© 2026 Morley Moses Apooch. All rights reserved.**

This work is created by a status Indian and represents Indigenous innovation and technological sovereignty. Copyright protection is automatic under international law (Berne Convention) and does not require registration.

**Unauthorized commercial use, modification, or derivative creation is strictly prohibited.**

For all licensing, permission, and legal inquiries, contact:
**apoochmorley@protonmail.com**

---

*This license represents a unified approach to protecting copyright, Indigenous rights, and intellectual property. All works are created by and owned by Morley Moses Apooch, a status Indian and band member of Yellow Quill First Nations. This license honors both international copyright law and Indigenous technological sovereignty.*

**Last Updated:** August 22, 2026  
**Status:** Active and Enforceable
